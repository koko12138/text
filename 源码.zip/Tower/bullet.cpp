﻿#include "bullet.h"
#include "gamehelper.h"

#include <QDebug>

Bullet::Bullet(QObject *parent)
    : GameObject(parent)
    , speed(-100)
    , damageValue(1)
{
}

void Bullet::copyOther(const Bullet &other)
{
    GameObject::copyOther(other);
    speed = other.speed;
    damageValue = other.damageValue;
}

Bullet *Bullet::duplicate() const
{
    Bullet *bullet = new Bullet;
    bullet->copyOther(*this);
    return bullet;
}

/*! 每帧更新子弹的位置 */
void Bullet::update()
{
    QTransform transfrom;
    transfrom.translate(pos().x(), pos().y());
    transfrom.rotate(rotation());
    transfrom.translate(0, speed * Time::deltaTime);
    setPos(transfrom.map(QPointF()));
}
