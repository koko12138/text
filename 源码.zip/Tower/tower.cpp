﻿#include "tower.h"
#include "gamehelper.h"
#include "bullet.h"
#include "blood.h"

#include <QDebug>
#include <QPainter>

Tower::Tower(QObject *parent)
    : GameObject(parent)
    , mIsAdvance(false)
    , mType(0)
    , mCoolTime(1.5)
    , mCoolTimer(0)
    , mBullet(nullptr)
    , mBlood(nullptr)
{
    setType(1);
}

Tower::~Tower()
{
    delete mBullet;
}

/*!
 * 设置炮塔的类型
 */
void Tower::setType(int type)
{
    if (mType == type) return;

    QString path, bulletPath;
    int damageValue = 1;                  // 子弹攻击力

    if (type > 0 && type <= 5) {        // 基础炮塔
        mIsAdvance = false;
        mType = type;
        damageValue = type * 5;
        path = QString(":/resources/tower/tower%1primary.png").arg(type);
        bulletPath = QString(":/resources/bullet/Bullet%1Primary.png").arg(type);
    } else if (type > 5 && type <= 10) {   // 升级版炮塔
        mIsAdvance = true;
        mType = type;
        damageValue = (type - 5) * 6;
        path = QString(":/resources/tower/tower%1advanced.png").arg(type - 5);
        bulletPath = QString(":/resources/bullet/Bullet%1Advanced.png").arg(type - 5);
    }

    // 背景图片
    if (!path.isEmpty())
        setBackground(QPixmap(path));

    // 血条
    if (mBlood) {
        mBlood->setRect(QRectF(0, 0, width() - 10, 5));
        mBlood->setPos(-mBlood->width() * 0.5, -height() * 0.5);
        mBlood->maxHealth = mBlood->currentHealth = 5;
    }

    // 炮塔所拥有的子弹
    if (!bulletPath.isEmpty()) {
        delete mBullet;
        mBullet = new Bullet;
        mBullet->setBackground(bulletPath);
        mBullet->damageValue = damageValue;
    }
}

/*!
 * 开启/关闭血条显示，默认是关闭的
 */
void Tower::enableBlood(bool enable)
{
    delete mBlood;
    mBlood = enable ? new Blood(this) : nullptr;

    if (mBlood) {
        mBlood->setRect(QRectF(0, 0, width() - 10, 5));
        mBlood->setPos(-mBlood->width() * 0.5, -height() * 0.5);
        mBlood->maxHealth = mBlood->currentHealth = 5;
    }
}

/*!
 * 复制other的属性
 */
void Tower::copyOther(const Tower &other)
{
    GameObject::copyOther(other);

    setType(other.type());

    mCoolTime = other.mCoolTime;
    mCoolTimer = other.mCoolTimer;

    if (mBullet) {
        mBullet->deleteLater();
        mBullet = nullptr;
    }

    if (mBlood) {
        mBlood->deleteLater();
        mBlood = nullptr;
    }

    if (other.mBullet)
        mBullet = other.mBullet->duplicate();

    if (other.mBlood)
        mBlood = other.mBlood->duplicate();
}

void Tower::takeDamage(int damage)
{
    if (!mBlood) return;

    mBlood->currentHealth -= damage;
    if (mBlood->currentHealth <= 0) {
        mBlood->currentHealth = 0;
        emit death(this);
    }
}

/*!
 * 复制一个炮塔
 */
Tower *Tower::duplicate() const
{
    Tower *tower = new Tower;
    tower->copyOther(*this);
    return tower;
}

/*!
 * 炮塔每发射一个子弹，就进入冷却时间
 */
void Tower::update()
{
    // 技能还在冷却当中
    if (mCoolTimer > 0) {
        mCoolTimer -= Time::deltaTime;
        return;
    } else mCoolTimer = mCoolTime;

    int count = 1;                  // 发射子弹个数
    double rotation = 0;     // 子弹旋转角度
    double angle = 15;        // 子弹旋转角度增量
    if (mType == 5 || mType == 10) {         // 最后一个炮塔才有5个子弹
        count = 5;
        rotation = -angle * 2;
    }

    for (int i = 0; i < count; ++i) {
        Bullet *bullet = mBullet->duplicate();
        bullet->setPos(pos().x(), pos().y() - height() * 0.5);
        bullet->setRotation(rotation);
        rotation += angle;
        GameHelper::centerRect(bullet);
        GameManager::TotalBullet.append(bullet);
    }
}

Card::Card(QObject *parent)
    : GameObject(parent)
    , mTower(new Tower(this))
    , mGold(0)
{
    setBackground(QPixmap(":/resources/materials/cardsitdeep.png"));
    mTower->setPos(QPointF((width() - mTower->width()) * 0.5, (height() - mTower->height()) * 0.5));
}

void Card::setGold(int gold)
{
    mGold = gold;
}

void Card::draw(QPainter *painter)
{
    GameObject::draw(painter);

    QFont font("Microsoft YaHei", 24);
    font.setBold(true);
    painter->setFont(font);
    painter->setPen(Qt::black);
    painter->drawText(rect(), Qt::AlignCenter, QString::number(mGold));
}
