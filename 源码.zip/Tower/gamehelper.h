﻿#ifndef GAMEHELPER_H
#define GAMEHELPER_H

#include <QTime>

class GameObject;
class Bullet;

class GameHelper
{
public:
    /*! 使 object 的(0, 0)点在矩形的中心 */
    static void centerRect(GameObject *object);
    static void topLeftRect(GameObject *object);
};

class GameManager
{
public:
   static QList<Bullet *> TotalBullet;
};

class Time
{
public:
    static const double FPS;            // 帧率
    static double deltaTime;          // 每帧所用的时间
    static QTime lastTime;             // 辅助deltaTime的计算
};

#endif // GAMEHELPER_H
