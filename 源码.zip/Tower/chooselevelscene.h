﻿#ifndef CHOOSELEVELSCENE_H
#define CHOOSELEVELSCENE_H

#include <QWidget>

class MyPushButton;
class PlayScene;

class ChooseLevelScene : public QWidget
{
    Q_OBJECT
public:
    explicit ChooseLevelScene(QWidget *parent = nullptr);
    ~ChooseLevelScene();

signals:
    void chooseSceneBack();

protected slots:
    void levelButtonClicked();

protected:
    virtual void paintEvent(QPaintEvent *) Q_DECL_OVERRIDE;
    virtual void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;
    virtual void closeEvent(QCloseEvent *) Q_DECL_OVERRIDE;

protected:
    QPixmap mBackground;
    MyPushButton *mBackButton;
    QList<MyPushButton *> mLevelButtons;

    PlayScene *mPlayScene;
};

#endif // CHOOSELEVELSCENE_H
