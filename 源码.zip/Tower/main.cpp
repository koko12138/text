﻿#include "mainscene.h"
#include "playscene.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainScene w;
//    PlayScene w;
    w.show();
    return a.exec();
}
